<div class="background">
    <div class="container">
        <h1 class="mt-4 text-light">About Me</h1>
        <p class="mt-2 text-light">Halo, nama saya <?= $data['nama']; ?>, umur saya <?= $data['umur']; ?> tahun, saya adalah seorang <?= $data['pekerjaan']; ?>.</p>
    </div>
</div>