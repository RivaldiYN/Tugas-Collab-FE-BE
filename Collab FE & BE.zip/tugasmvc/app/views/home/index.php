<div class="background">
    <div class="container">
        <div class="jumbotron jumbotron-fluid mt-4">
            <div class="container">
                <h1 class="display-4">Selamat Datang di Website Saya</h1>
                <p>Halo, nama saya <?= $data['nama'] ?>, anda akan melihat daftar nama peminjam motor di SewaMotor.id</p>
            </div>
        </div>
    </div>
</div>