<?php

class User_model
{
    private $nama = 'Rivaldi';

    public function getUser()
    {
        return $this->nama;
    }
}
